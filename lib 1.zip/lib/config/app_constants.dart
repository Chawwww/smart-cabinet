import 'package:flutter/material.dart';

class AppConstants {
  // =========================
  // App Info
  // =========================
  static const String appName = "Smart Cabinet Finder";
  static const String appVersion = "1.0.0";

  // =========================
  // Firestore Collections
  // =========================
  static const String usersCollection = "users";
  static const String categoriesCollection = "categories";
  static const String cabinetsCollection = "cabinets";
  static const String boxesCollection = "boxes";
  static const String itemsCollection = "items";
  static const String doorLogsCollection = "door_logs";
  static const String notificationsCollection = "notifications";

  // =========================
  // BLE UUIDs (ESP32)
  // =========================
  static const String bleServiceUUID =
      "4fafc201-1fb5-459e-8fcc-c5c9c331914b";

  static const String doorSensorCharacteristic =
      "beb5483e-36e1-4688-b7f5-ea07361b26a8";

  static const String servoCharacteristic =
      "beb5483e-36e1-4688-b7f5-ea07361b26a9";

  static const String ledCharacteristic =
      "beb5483e-36e1-4688-b7f5-ea07361b26aa";

  // =========================
  // MQTT
  // =========================
  static const String mqttServer = "broker.hivemq.com";
  static const int mqttPort = 1883;

  static const String mqttDoorTopic =
      "smart_cabinet/door";

  static const String mqttLedTopic =
      "smart_cabinet/led";

  static const String mqttServoTopic =
      "smart_cabinet/servo";

  // =========================
  // Gemini AI
  // =========================
  static const String geminiApiKey =
      "AQ.Ab8RN6Kln8bSIpqqCdlDOYpn5bN4H_EAoqQqK2xDaf3Forfsmg";

  // =========================
  // Item Status
  // =========================
  static const String statusNormal = "normal";
  static const String statusExpiringSoon = "expiring_soon";
  static const String statusExpired = "expired";

  // =========================
  // Item State
  // =========================
  static const String itemInside = "inside";
  static const String itemTaken = "taken";
  static const String itemUsed = "used";
  static const String itemDamaged = "damaged";

  // =========================
  // Notification Types
  // =========================
  static const String notificationExpiry = "expiry";
  static const String notificationLowStock = "low_stock";
  static const String notificationDoorOpen = "door_open";
  static const String notificationReminder = "reminder";

  // =========================
  // Route Names
  // =========================
  static const String routeLogin = "/login";
  static const String routeRegister = "/register";
  static const String routeHome = "/home";
  static const String routeItems = "/items";
  static const String routeSearch = "/search";
  static const String routeProfile = "/profile";
  static const String routeNotifications = "/notifications";
  static const String routeWorkflows = "/workflows";
  static const String routeMenu = "/menu";
  static const String routeAiChat = "/ai-chat";

  // =========================
  // Shared Preferences Keys
  // =========================
  static const String themeKey = "theme_mode";
  static const String userIdKey = "user_id";
  static const String firstLaunchKey = "first_launch";

  // =========================
  // Default Categories
  // =========================
  static const List<Map<String, dynamic>> defaultCategories = [
    {
      "name": "Medicine",
      "icon": "💊",
      "color": "#FF6B6B",
    },
    {
      "name": "Food",
      "icon": "🍕",
      "color": "#FFA94D",
    },
    {
      "name": "Drinks",
      "icon": "🥤",
      "color": "#4ECDC4",
    },
    {
      "name": "Tools",
      "icon": "🔧",
      "color": "#45B7D1",
    },
    {
      "name": "Documents",
      "icon": "📄",
      "color": "#96CEB4",
    },
    {
      "name": "Others",
      "icon": "📦",
      "color": "#DDA0DD",
    },
  ];
}

class NavItem {
  final IconData icon;
  final String label;
  final String route;

  const NavItem({
    required this.icon,
    required this.label,
    required this.route,
  });
}

class NavigationItems {
  static const List<NavItem> items = [
    NavItem(
      icon: Icons.home,
      label: "Home",
      route: AppConstants.routeHome,
    ),
    NavItem(
      icon: Icons.inventory_2,
      label: "Items",
      route: AppConstants.routeItems,
    ),
    NavItem(
      icon: Icons.search,
      label: "Search",
      route: AppConstants.routeSearch,
    ),
    NavItem(
      icon: Icons.notifications,
      label: "Notifications",
      route: AppConstants.routeNotifications,
    ),
    NavItem(
      icon: Icons.smart_toy,
      label: "AI Assistant",
      route: AppConstants.routeAiChat,
    ),
    NavItem(
      icon: Icons.person,
      label: "Profile",
      route: AppConstants.routeProfile,
    ),
  ];
}