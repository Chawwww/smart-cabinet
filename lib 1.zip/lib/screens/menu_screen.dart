// lib/screens/menu_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/theme_provider.dart';
import 'profile_screen.dart';
import 'login_screen.dart';
import 'home_screen.dart';

class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final themeProvider = context.watch<ThemeProvider>();
    final user = authProvider.currentUser;
    
    return Container(
      color: const Color(0xFFF2FFFF),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: const Color(0xFF4ECDC4),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Center(
                      child: Text(
                        user != null && user.name.isNotEmpty
                            ? user.name[0].toUpperCase()
                            : 'G',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          user?.name ?? 'Guest User',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF2D3436),
                          ),
                        ),
                        Text(
                          user?.email ?? 'guest@example.com',
                          style: const TextStyle(
                            fontSize: 14,
                            color: Color(0xFF636E72),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (!authProvider.isLoggedIn)
                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const LoginScreen(),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF4ECDC4),
                        minimumSize: const Size(80, 36),
                      ),
                      child: const Text('Login'),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          _buildMenuItem(
            context,
            icon: Icons.person_outline,
            title: 'User Profile',
            onTap: () {
              if (authProvider.isLoggedIn) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ProfileScreen()),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Please login first')),
                );
              }
            },
          ),
          _buildMenuItem(
            context,
            icon: Icons.business, // Fixed: changed from business_outline
            title: 'Company Details',
            badge: 'NEW',
            onTap: () {},
          ),
          _buildMenuItem(
            context,
            icon: Icons.location_on, // Fixed: changed from location_on_outline
            title: 'Addresses',
            badge: 'NEW',
            onTap: () {},
          ),
          _buildMenuItem(
            context,
            icon: Icons.assessment_outlined,
            title: 'Reports',
            onTap: () {},
          ),
          _buildMenuItem(
            context,
            icon: Icons.cloud_upload_outlined,
            title: 'Bulk Import',
            onTap: () {},
          ),
          _buildMenuItem(
            context,
            icon: Icons.settings_outlined,
            title: 'Custom Fields',
            onTap: () {},
          ),
          _buildMenuItem(
            context,
            icon: Icons.label_outlined,
            title: 'Create Labels',
            onTap: () {},
          ),
          _buildMenuItem(
            context,
            icon: Icons.local_offer_outlined,
            title: 'Manage Tags',
            onTap: () {},
          ),
          _buildMenuItem(
            context,
            icon: Icons.sync_outlined,
            title: 'Sync Inventory',
            onTap: () {},
          ),
          _buildMenuItem(
            context,
            icon: Icons.newspaper_outlined,
            title: 'Product News',
            badge: 'NEW',
            onTap: () {},
          ),
          _buildMenuItem(
            context,
            icon: Icons.help_outline,
            title: 'Help & Support',
            onTap: () {},
          ),
          const Divider(),
          _buildMenuItem(
            context,
            icon: Icons.dark_mode_outlined,
            title: 'Dark Mode',
            trailing: Switch(
              value: themeProvider.isDarkMode,
              onChanged: (_) => themeProvider.toggleTheme(),
              activeThumbColor: const Color(0xFF4ECDC4), // Fixed: activeColor -> activeThumbColor
            ),
            onTap: () {},
          ),
          const Divider(),
          if (authProvider.isLoggedIn)
            _buildMenuItem(
              context,
              icon: Icons.logout,
              title: 'Sign Out',
              color: Colors.red,
              onTap: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('Sign Out'),
                    content: const Text('Are you sure you want to sign out?'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text('Cancel'),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text('Sign Out'),
                      ),
                    ],
                  ),
                );
                if (confirm == true) {
                  await authProvider.logout();
                  if (context.mounted) {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => const HomeScreen()),
                    );
                  }
                }
              },
            ),
          const SizedBox(height: 16),
          const Text(
            'Version 1.0.0',
            style: TextStyle(
              fontSize: 12,
              color: Color(0xFFB2BEC3),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildMenuItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    String? badge,
    Widget? trailing,
    Color? color,
    VoidCallback? onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: color ?? const Color(0xFF2D3436)),
      title: Text(
        title,
        style: TextStyle(
          color: color ?? const Color(0xFF2D3436),
        ),
      ),
      trailing: badge != null
          ? Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFF6B6B),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    badge,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 4),
                const Icon(Icons.chevron_right, size: 20),
              ],
            )
          : trailing ?? const Icon(Icons.chevron_right, size: 20),
      onTap: onTap,
    );
  }
}